<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Restaurant extends Model
{
    //
    protected $fillable = [
        'name', 'type'
    ];


    public function dishes()
    {
        return $this->hasMany('App\Entities\Dish', 'rest_id');
    }

    public function locations()
    {
        return $this->hasMany('App\Entities\Location');
    }
}
