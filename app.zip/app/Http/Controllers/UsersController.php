<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Response\JSendResponse;
use App\Entities\User;
use App\Entities\Role;
use Auth;
use JWTAuth;
use stdClass;
use App\Http\Requests;

class UsersController extends Controller
{

    ///Create a new User 
    public function create()
    {

    	$input = Input::all();
    	$validator = Validator::make($input, [
            'name' => 'required',
            'password' => 'required|min:8',
            'email' => 'required|email',
            'role_name' => 'required'  //string
        ]);
        if ($validator->fails()) {
  			$fail = JSendResponse::fail(['message' => 'Validaion error', 'errors' => $validator->messages()]);
        	return response($message, 401);
       	}
        $role_name = Input::get("role_name");
        $role = Role::where('name', '=', $role_name)->first();
        
        $created = $user = new User;
       	$user->name = Input::get('name');
       	$user->email = Input::get('email');
       	$password = Hash::make(Input::get('password'));
        if($role){
          $user->role_id = $role->id;
        }else{
          $message = "Role name doesnt exist";
          return response($message, 401);
        }
        
        
       	$user->password = $password;
       	$user->save();

       	$success = JSendResponse::success(['message' => "New user has been created", 'id' => $created->id]);
        return $success;
    }

    

    public function update($id)
    {
        $user = User::where('id', $id)->find($id);
        $user->name = Input::get('name');
        $user->email = Input::get('email');
        $password = Hash::make(Input::get('password'));

        $role_name = Input::get("role_name");
        $role = Role::where('name', '=', $role_name)->first();
        
        $user->role_id = $role->id;
        $user->password = $password;
        $user->update();
        $userupdated = $user->save();
        if($userupdated){
            $message = JSendResponse::success(['message' => 'User Successfully Updated', 'input'=>Input::all()]);
        }else{
            $message = JSendResponse::fail(['message' => 'User Couldnt be Updated']);
            return response($message, 401);
        }
        return $message;

        
    }

    public function getUsersByRoleID($role_id) 
    {
      $users = User::getUsersByRoleID($role_id);
      $jsend = JSendResponse::success($users->toArray());
      return $jsend;
    }

    public function getUserByID($id) 
    {
      $user = User::find($id)->first();
      $jsend = JSendResponse::success($user->toArray());
      return $jsend;
    }

    public function getAllUsers()
    {

      $users = User::all();
      $jsend = JSendResponse::success($users->toArray());
      return $jsend;
    }

    public function delete($id)
 {
     $user = User::where('id', $id)->first();
     if($user){
           $userdeleted = $user->delete($id);
       if($userdeleted){
          $success = JSendResponse::success(['message' => 'user deleted successfully', 'input'=>Input::all()]);
       }
       return $success;
     }

 }


}
