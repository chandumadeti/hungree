<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Response\JSendResponse;
use App\Entities\Media;
use Auth;
use JWTAuth;
use stdClass;
use App\Http\Requests;



class MediasController extends Controller
{
    //Create new media

    public function create()
    {
    	$input = Input::all();
    	$validator = Validator::make($input, [
    		  'name' => 'required',
    		  'type' => 'required',
    		  'url' => 'required',
    	    ]);
    	    if($validator->fails()){
    	    	$fail  = JSendRsponse::fail(['message' => 'Validation Error', 'error' => $validator->messages()]);
    	    	   return response($fail, 401);
    	    }

    	    $created = $media = new Media;
    	    $media->name = Input::get('name');
    	    $media->type = Input::get('type');
    	    $media->url = Input::get('url');
    	    $media->save();
    	    $success = JSendResponse::success(['message' => 'Media Created Successfully', 'id' => $created->id]);
    	    return $success;
    }


    //Update Media
    public function update($id)
    {	
    	
        $media = Media::where('id', $id)->find($id);
        $media->name = Input::get('name');
    	$media->type = Input::get('type');
    	$media->url = Input::get('url');
        $media->update();
        $media->save();
        $success = JSendResponse::success(['message' => 'Media Successfully Edited', 'input' => Input::all()]);
        return $success;
    }

    public function getMediaById($id)
    {
    	$media = Media::find($id);
    	$jsend = JSendResponse::success($media->toArray());
    	return $jsend;
    }

    public function getAllMedias()
    {
    	$media = Media::all();
    	$jsend = JSendResponse::success($media->toArray());
    	return $jsend;
    }

    public function delete($id)
    {
    	$media = Media::where('id', $id)->first();
    	if($media){
    		$mediadeleted = $media->delete($id);
    		if($mediadeleted){
    			$success = JSendResponse::success(['message' => 'media removed Successfully']);
    			return $success;
    		
    		}
    	}
    	
    }

}
