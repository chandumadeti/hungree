<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Response\JSendResponse;
use App\Entities\Restaurant;
use Auth;
use JWTAuth;
use stdClass;
use App\Http\Requests;

class RestaurantsController extends Controller
{
    //Create a new restaurant

    public function create()
    {

    	$input = Input::all();
    	$validator = Validator::make($input, [
            'name' => 'required',
            'type' => 'required',
            
        ]);
        if ($validator->fails()) {
  			$fail = JSendResponse::fail(['message' => 'Validaion error', 'errors' => $validator->messages()]);
        	return response($message, 401);
       	}
        
        $created = $restaurant = new Restaurant;
       	$restaurant->name = Input::get('name');
       	$restaurant->type = Input::get('type');
       	$restaurant->save();
       	$success = JSendResponse::success(['message' => "New Restaurant has been created", 'id' => $created->id]);
        return $success;
    }


    public function update($id)
    {
        $restaurant = Restaurant::where('id', $id)->find($id);
        $restaurant->name = Input::get('name');
        $restaurant->type = Input::get('type');
        $restaurant->update();
        $restaurantupdated = $restaurant->save();
        if($restaurantupdated){
            $message = JSendResponse::success(['message' => 'Restaurant Successfully Updated', 'input'=>Input::all()]);
            return $message;

        }else{
            $message = JSendResponse::fail(['message' => 'Restaurant Couldnt be Updated']);
            return response($message, 401);

        }
    }

    public function getRestaurantByID($id) 
    {
      $restaurant = Restaurant::find($id)->first();
      $jsend = JSendResponse::success($restaurant->toArray());
      return $jsend;
    }

    public function getAllRestaurants()
    {

      $restaurants = Restaurant::all();
      $jsend = JSendResponse::success($restaurants->toArray());
      return $jsend;
    }

    public function delete($id)
 	 {
     $restaurant = Restaurant::where('id', $id)->first();
     if($restaurant){
           $restaurantdeleted = $restaurant->delete($id);
       if($restaurantdeleted){
          $success = JSendResponse::success(['message' => 'restaurant deleted successfully', 'input'=>Input::all()]);
       }
       return $success;
     }
    }


    public function getDishesByrestaurant($rest_id)
    {
      $restaurant = Restaurant::find($rest_id);
      if($restaurant){
        $dishes = $restaurant->dishes()->get();
        $jsend = JSendResponse::success($dishes->toArray());
      }else{
        $message = JSendResponse::fail(['message' => 'Couldnt find dish']);
        return response($message, 401);
      }
      return $jsend;
    }

    
}