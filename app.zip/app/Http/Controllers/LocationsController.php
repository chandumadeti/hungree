<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Response\JSendResponse;
use App\Entities\Location;
use Auth;
use JWTAuth;
use stdClass;
use App\Http\Requests;

class LocationsController extends Controller
{
    //Create new Location
    public function create()
    {
    	$input = Input::all();
    	$validator = Validator::make($input, [
    		'name' => 'required',
    		]);

    	if($validator->fails()){
    		$fail = JSendResponse::fail(['message' => 'Validation Error', 'errors' => $validator->messages()]);
    		return response($fail, 401);
    	}

    	$created = $location = new Location;
    	$location->name = Input::get('name');
    	$location->save();
    	$success = JSendResponse::success(['message' => 'Location created Successfully', 'id' => $created->id]);
    	return $success;
    }



    


    public function update($id)
    {	
    	
        $location = Location::where('id', $id)->find($id);
        $location->name = Input::get('name');
    	$location->update();
        $location->save();
        $success = JSendResponse::success(['message' => 'Location Successfully Edited', 'input' => Input::all()]);
        return $success;
    }




    

    public function getLocationByID($id)
    {
    	$location = Location::find($id)->first();
    	$jsend = JSendResponse::success($location->toArray());
    	return $jsend;
    }

    public function getAllLocations()
    {
    	$locations = Location::all();
    	$jsend = JSendResponse::success($locations->toArray());
    	return $jsend;
    }

    public function delete($id)
    {
    	$location = Location::where('$id', id)->first();
    	if($location){
    		$locationdeleted = $location->delete($id);
          if($locationdeleted){
          	$success = JSendResponse::success(['message' => 'Location Deleted Successfully']);
            return $success;	
          }         
    	}
    }

    public function getRestaurantBylocation($location_id)
    {
      $location = Location::find($location_id);
      if($location){
        $restaurants = $location->restaurants()->get();
        $jsend = JSendResponse::success($restaurants->toArray());
      }else{
        $message = JSendResponse::fail(['message' => 'Couldnt find resaurant']);
        return response($message, 401);
      }
      return $jsend;
    }  


}

