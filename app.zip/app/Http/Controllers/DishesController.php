<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Response\JSendResponse;
use App\Entities\Dish;
use Auth;
use JWTAuth;
use stdClass;
use App\Http\Requests;

class DishesController extends Controller
{
    
    //create a new dish

    public function create()
    {

    	$input = Input::all();
    	$validator = Validator::make($input, [
            'name' => 'required',
            'category' => 'required',
            'veggie' => 'required',
            
        ]);
        if ($validator->fails()) {
  			$fail = JSendResponse::fail(['message' => 'Validaion error', 'errors' => $validator->messages()]);
        	return response($message, 401);
       	}
        
        $created = $dish = new Dish;
       	$dish->name = Input::get('name');
       	$dish->category = Input::get('category');
       	$dish->veggie = Input::get('veggie');
       	$dish->save();
       	$success = JSendResponse::success(['message' => "New Dish has been created", 'id' => $created->id]);
        return $success;
    }


    public function update($id)
    {
        $dish = Dish::where('id', $id)->first();
        $dish->name = Input::get('name');
       	$dish->category = Input::get('category');
       	$dish->veggie = Input::get('veggie');
       	$dish->update();
        $dishupdated = $dish->save();
        if($dishupdated){
            $message = JSendResponse::success(['message' => 'Dish Successfully Updated', 'input'=>Input::all()]);
            return $message;
        }else{
            $message = JSendResponse::fail(['message' => 'Dish Couldnt be Updated']);
            return response($message, 401);

        }

        
    }

    public function getDishByID($id) 
    {
      $dish = Dish::find($id)->first();
      $jsend = JSendResponse::success($dish->toArray());
      return $jsend;
    }

    public function getAllDishes()
    {

      $dishes = Dish::all();
      $jsend = JSendResponse::success($dishes->toArray());
      return $jsend;
    }

    public function getDishesByRestaurantID($id)
    {
    $dishes = Dish::with('restaurant')->where('rest_id', $id)->get();
    $jsend = JSendResponse::success($dishes->toArray());
    return $jsend;
    }

    public function getDishesByCategory($category)
    {
      $dishes = Dish::with('category', $category)->get();

      foreach ($dishes as $dish) {
      echo $dish->category;
      }
    }  

   
    public function delete($id)
 	 {
     $dish = Dish::where('id', $id)->first();
     if($dish){
           $dishdeleted = $dish->delete($id);
       if($dishdeleted){
          $success = JSendResponse::success(['message' => 'dish deleted successfully', 'input'=>Input::all()]);
       }
       return $success;
     }
    } 

}
