<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::group(array('prefix' => 'api/v1', 'middleware' => ['web']), function()
{
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods:  POST, GET, OPTIONS, PUT, DELETE');
    header('Access-Control-Allow-Headers:  Content-Type, X-Auth-Token, Origin, Authorization');

    //Create User APIS
    
    Route::post('/user', 'UsersController@create');
    Route::post('/user/{id}', 'UsersController@update');
    Route::get('/user/{id}', 'UsersController@getUserByID');
    Route::get('/users', 'UsersController@getAllUsers');
    Route::delete('/user/{id}', 'UsersController@delete');

    //Create Restaurant APIS
    
    Route::post('/restaurant', 'RestaurantsController@create');
    Route::post('/restaurant/{id}', 'RestaurantsController@update');
    Route::get('/restaurant/{id}', 'RestaurantsController@getRestaurantByID');
    Route::get('/restaurants', 'RestaurantsController@getAllRestaurants');
    Route::delete('/restaurant/{id}', 'RestaurantsController@delete');
    Route::get('/restaurantdishes/{rest_id}', 'RestaurantsController@getDishesByRestaurant');
    

    //Create Dish APIS
    
    Route::post('/dish', 'DishesController@create');
    Route::post('/dish/{id}', 'DishesController@update');
    Route::get('/dish/{id}', 'DishesController@getDishByID');
    Route::get('/dishes', 'DishesController@getAllDishes');
    Route::delete('/dish/{id}', 'DishesController@delete');
    Route::get('/dishes/{rest_id}', 'DishesController@getDishesByRestaurantID');
    Route::get('/dishes/{category}', 'DishesController@getDishesByCategory');

    //Create Media APIS

    Route::post('/media', 'MediasController@create');
    Route::post('/media/{id}', 'MediasController@update');
    Route::get('/media/{id}', 'MediasController@getMediaByID');
    Route::get('/medias', 'MediasController@getAllMedias');
    Route::delete('/media/{id}', 'MediasController@delete');

    //Create Location APIS

    Route::post('/location', 'LocationsController@create');
    Route::post('/location/{id}', 'LocationsController@update');
    Route::get('/location/{id}', 'LocationsController@getLocationByID');
    Route::get('/locations', 'LocationsController@getAllLocations');
    Route::delete('/location', 'LocationsController@delete');
    Route::get('/restaurantlocation/{location_id}', 'LocationsController@getRestaurantBylocation');

    //Secure Routes
    Route::group(['middleware' => 'jwt-auth'], function () {
        
    });

});
